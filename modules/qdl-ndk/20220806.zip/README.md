# QDL For Android NDK
Qualcomm Download (QDL) is a tool to communicate with Qualcomm System On a Chip bootroms to install or execute code.
As open source tool (for Linux) that implements the Qualcomm Sahara and Firehose protocols has been developed by Linaro, and can be used for program (or unbrick) MSM based devices.
Static binary build for Android multi architecture target builded by NDK.

# License
* [BSD 3-Clause](https://raw.githubusercontent.com/andersson/qdl/master/LICENSE)

## Source Code
* https://github.com/andersson/qdl

## Credits
* [Bjorn Andersson](https://github.com/andersson)
* Linaro Landing Teams