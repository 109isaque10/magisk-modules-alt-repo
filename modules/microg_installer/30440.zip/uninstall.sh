pm uninstall com.google.android.gms
pm uninstall com.android.vending
